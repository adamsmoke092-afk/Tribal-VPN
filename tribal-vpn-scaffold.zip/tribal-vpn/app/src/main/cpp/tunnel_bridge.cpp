// tunnel_bridge.cpp
//
// JNI bridge between Kotlin (NativeTunnelBridge.kt) and the native tunnel
// engines (hev-socks5-tunnel for Phase 4, badvpn-udpgw for Phase 5).
//
// STATUS: stub only. Neither library is vendored yet (see CMakeLists.txt
// comments). These functions currently return an error code and log a
// clear "not implemented" message rather than pretending to succeed —
// consistent with this project's no-fabricated-state rule.

#include <jni.h>
#include <android/log.h>

#define LOG_TAG "TribalTunnelBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {

/**
 * Phase 4: start the tun -> SOCKS5 relay.
 *
 * @param tun_fd      fd of the already-established VpnService tun interface
 * @param socks_addr  loopback address of the SshTunnelService SOCKS5 listener
 * @param socks_port  port of that listener
 * @return 0 on success, negative error code otherwise. Currently always
 *         returns -1 (ENOSYS-equivalent) since hev-socks5-tunnel is not
 *         yet linked in.
 */
JNIEXPORT jint JNICALL
Java_com_tribal_vpn_vpn_NativeTunnelBridge_nativeStartTunnel(
        JNIEnv *env, jobject /* this */,
        jint tun_fd, jstring socks_addr, jint socks_port) {

    const char *addr = env->GetStringUTFChars(socks_addr, nullptr);
    LOGE("nativeStartTunnel called (tun_fd=%d, socks=%s:%d) but "
         "hev-socks5-tunnel is not vendored yet — returning -1. "
         "See app/src/main/cpp/CMakeLists.txt for wiring instructions.",
         tun_fd, addr, socks_port);
    env->ReleaseStringUTFChars(socks_addr, addr);

    return -1;
}

/**
 * Phase 4: stop the tun -> SOCKS5 relay started above.
 */
JNIEXPORT void JNICALL
Java_com_tribal_vpn_vpn_NativeTunnelBridge_nativeStopTunnel(
        JNIEnv *env, jobject /* this */) {
    LOGI("nativeStopTunnel called (no-op — tunnel was never started)");
}

/**
 * Phase 5: start the UDP gateway client (badvpn-udpgw protocol).
 *
 * @return 0 on success, negative error code otherwise. Currently always
 *         returns -1 since badvpn-udpgw is not vendored yet.
 */
JNIEXPORT jint JNICALL
Java_com_tribal_vpn_vpn_NativeTunnelBridge_nativeStartUdpGateway(
        JNIEnv *env, jobject /* this */,
        jint tun_fd, jstring udpgw_addr, jint udpgw_port) {

    const char *addr = env->GetStringUTFChars(udpgw_addr, nullptr);
    LOGE("nativeStartUdpGateway called (tun_fd=%d, udpgw=%s:%d) but "
         "badvpn-udpgw is not vendored yet — returning -1.",
         tun_fd, addr, udpgw_port);
    env->ReleaseStringUTFChars(udpgw_addr, addr);

    return -1;
}

JNIEXPORT void JNICALL
Java_com_tribal_vpn_vpn_NativeTunnelBridge_nativeStopUdpGateway(
        JNIEnv *env, jobject /* this */) {
    LOGI("nativeStopUdpGateway called (no-op)");
}

} // extern "C"
