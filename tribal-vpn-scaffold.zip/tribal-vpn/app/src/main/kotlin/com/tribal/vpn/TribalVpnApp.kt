package com.tribal.vpn

import android.app.Application

class TribalVpnApp : Application()
